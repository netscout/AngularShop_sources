package com.angularShop.angularShop

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AngularShopApplicationTests {

	@Test
	fun contextLoads() {
	}

}
