package com.angularShop.angularShop

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AngularShopApplication

fun main(args: Array<String>) {
	runApplication<AngularShopApplication>(*args)
}
