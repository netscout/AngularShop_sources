rootProject.name = "angularShop"
